Api.requireAuth();

const user = Api.user();
const params = new URLSearchParams(window.location.search);
const projectId = params.get('id');

if (!projectId) window.location.href = 'dashboard.html';

let project = null;
let tasks = [];
let notifications = [];
let activeTaskId = null;
let socket = null;

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function renderSidebarUser() {
  document.getElementById('sidebar-user').innerHTML = `
    <span class="avatar">${initials(user.name)}</span>
    <span>${user.name}</span>
  `;
}

async function loadSidebarProjects() {
  const { projects } = await Api.get('/projects');
  const list = document.getElementById('sidebar-project-list');
  list.innerHTML = projects
    .map(
      (p) =>
        `<li><a href="board.html?id=${p._id}" class="${p._id === projectId ? 'active' : ''}">${escapeHtml(p.name)}</a></li>`
    )
    .join('');
}

// ---- Load project + members ----
async function loadProject() {
  const data = await Api.get(`/projects/${projectId}`);
  project = data.project;
  document.getElementById('project-name').textContent = project.name;

  const avatars = document.getElementById('member-avatars');
  avatars.innerHTML = project.members
    .map((m) => `<span class="avatar" title="${escapeHtml(m.user.name)}">${initials(m.user.name)}</span>`)
    .join('');

  populateAssigneeSelect(document.getElementById('task-assignee'));
  populateAssigneeSelect(document.getElementById('detail-assignee'));
  renderMemberPills();
}

function populateAssigneeSelect(select) {
  const current = select.value;
  select.innerHTML =
    '<option value="">Unassigned</option>' +
    project.members.map((m) => `<option value="${m.user._id}">${escapeHtml(m.user.name)}</option>`).join('');
  select.value = current;
}

function renderMemberPills() {
  document.getElementById('member-pills').innerHTML = project.members
    .map(
      (m) =>
        `<span class="member-pill"><span class="avatar" style="width:20px;height:20px;font-size:9px;">${initials(m.user.name)}</span>${escapeHtml(m.user.name)}</span>`
    )
    .join('');
}

// ---- Load + render tasks ----
async function loadTasks() {
  const data = await Api.get(`/tasks/${projectId}`);
  tasks = data.tasks;
  renderBoard();
}

function renderBoard() {
  ['todo', 'in-progress', 'done'].forEach((status) => {
    const container = document.getElementById(`cards-${status}`);
    const items = tasks.filter((t) => t.status === status);
    document.getElementById(`count-${status}`).textContent = items.length;
    container.innerHTML = items.map(taskCardHtml).join('');
  });
  attachCardListeners();
}

function taskCardHtml(task) {
  const dueLabel = task.dueDate ? formatDate(task.dueDate) : '';
  const overdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'done';
  const assigneeInitials = task.assignedTo ? initials(task.assignedTo.name) : '';
  return `
    <div class="task-card" draggable="true" data-id="${task._id}">
      <h4>${escapeHtml(task.title)}</h4>
      ${task.description ? `<p class="task-desc">${escapeHtml(task.description)}</p>` : ''}
      <div class="task-footer">
        <span class="due ${overdue ? 'overdue' : ''}">${dueLabel}</span>
        <div style="display:flex; align-items:center; gap:6px;">
          ${assigneeInitials ? `<span class="avatar" style="width:22px;height:22px;font-size:10px;" title="${escapeHtml(task.assignedTo.name)}">${assigneeInitials}</span>` : ''}
          <span class="stamp stamp-${task.priority}">${task.priority[0].toUpperCase()}</span>
        </div>
      </div>
    </div>`;
}

function formatDate(d) {
  return new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function attachCardListeners() {
  document.querySelectorAll('.task-card').forEach((card) => {
    card.addEventListener('click', () => openTaskDetail(card.dataset.id));
    card.addEventListener('dragstart', () => card.classList.add('dragging'));
    card.addEventListener('dragend', () => card.classList.remove('dragging'));
  });
}

// ---- Drag and drop between columns ----
document.querySelectorAll('.col').forEach((col) => {
  col.addEventListener('dragover', (e) => {
    e.preventDefault();
    col.classList.add('drag-over');
  });
  col.addEventListener('dragleave', () => col.classList.remove('drag-over'));
  col.addEventListener('drop', async (e) => {
    e.preventDefault();
    col.classList.remove('drag-over');
    const dragging = document.querySelector('.task-card.dragging');
    if (!dragging) return;
    const taskId = dragging.dataset.id;
    const newStatus = col.dataset.status;
    const task = tasks.find((t) => t._id === taskId);
    if (!task || task.status === newStatus) return;
    task.status = newStatus; // optimistic update
    renderBoard();
    try {
      await Api.patch(`/tasks/item/${taskId}`, { status: newStatus });
    } catch (err) {
      showToast(err.message);
      loadTasks();
    }
  });
});

// ---- Add task modal ----
const taskFormOverlay = document.getElementById('task-form-overlay');
document.querySelectorAll('.add-task-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.getElementById('task-form').reset();
    document.getElementById('task-form-title').textContent = 'New task';
    document.getElementById('task-form-status').value = btn.dataset.status;
    document.getElementById('task-form-error').textContent = '';
    taskFormOverlay.classList.add('open');
  });
});

document.getElementById('task-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('task-form-error');
  errorEl.textContent = '';
  try {
    const body = {
      title: document.getElementById('task-title').value.trim(),
      description: document.getElementById('task-description').value.trim(),
      assignedTo: document.getElementById('task-assignee').value || null,
      priority: document.getElementById('task-priority').value,
      dueDate: document.getElementById('task-due').value || null,
    };
    const status = document.getElementById('task-form-status').value;
    const { task } = await Api.post(`/tasks/${projectId}`, body);
    if (status !== 'todo') {
      await Api.patch(`/tasks/item/${task._id}`, { status });
    }
    taskFormOverlay.classList.remove('open');
    loadTasks();
    showToast('Task created');
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

// ---- Task detail modal ----
async function openTaskDetail(taskId) {
  activeTaskId = taskId;
  const task = tasks.find((t) => t._id === taskId);
  if (!task) return;

  document.getElementById('detail-title').textContent = task.title;
  document.getElementById('detail-description').textContent = task.description || 'No description.';
  document.getElementById('detail-status').value = task.status;
  document.getElementById('detail-priority').value = task.priority;
  document.getElementById('detail-due').value = task.dueDate ? task.dueDate.slice(0, 10) : '';

  populateAssigneeSelect(document.getElementById('detail-assignee'));
  document.getElementById('detail-assignee').value = task.assignedTo ? task.assignedTo._id : '';

  document.getElementById('task-detail-overlay').classList.add('open');
  loadComments(taskId);
}

['detail-status', 'detail-priority', 'detail-assignee', 'detail-due'].forEach((id) => {
  document.getElementById(id).addEventListener('change', async (e) => {
    const field = { 'detail-status': 'status', 'detail-priority': 'priority', 'detail-assignee': 'assignedTo', 'detail-due': 'dueDate' }[id];
    try {
      await Api.patch(`/tasks/item/${activeTaskId}`, { [field]: e.target.value || null });
      loadTasks();
      showToast('Task updated');
    } catch (err) {
      showToast(err.message);
    }
  });
});

document.getElementById('delete-task-btn').addEventListener('click', async () => {
  if (!confirm('Delete this task? This cannot be undone.')) return;
  try {
    await Api.delete(`/tasks/item/${activeTaskId}`);
    document.getElementById('task-detail-overlay').classList.remove('open');
    loadTasks();
    showToast('Task deleted');
  } catch (err) {
    showToast(err.message);
  }
});

// ---- Comments ----
async function loadComments(taskId) {
  const { comments } = await Api.get(`/comments/${taskId}`);
  renderComments(comments);
}

function renderComments(comments) {
  const thread = document.getElementById('comment-thread');
  if (!comments.length) {
    thread.innerHTML = '<p class="muted" style="font-size:13px;">No comments yet. Start the conversation below.</p>';
    return;
  }
  thread.innerHTML = comments
    .map(
      (c) => `
      <div class="comment-item">
        <span class="avatar">${initials(c.author.name)}</span>
        <div class="comment-body">
          <div class="c-meta"><span>${escapeHtml(c.author.name)}</span><span>${timeAgo(c.createdAt)}</span></div>
          <p>${escapeHtml(c.text)}</p>
        </div>
      </div>`
    )
    .join('');
  thread.scrollTop = thread.scrollHeight;
}

document.getElementById('comment-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('comment-input');
  const text = input.value.trim();
  if (!text) return;
  try {
    await Api.post(`/comments/${activeTaskId}`, { text });
    input.value = '';
    loadComments(activeTaskId);
  } catch (err) {
    showToast(err.message);
  }
});

// ---- Invite member ----
document.getElementById('invite-btn').addEventListener('click', () => {
  document.getElementById('invite-error').textContent = '';
  document.getElementById('invite-overlay').classList.add('open');
});

document.getElementById('invite-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('invite-error');
  errorEl.textContent = '';
  try {
    const email = document.getElementById('invite-email').value.trim();
    await Api.post(`/projects/${projectId}/members`, { email });
    document.getElementById('invite-email').value = '';
    showToast('Member added');
    loadProject();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

// ---- Generic modal close handling ----
document.querySelectorAll('[data-close]').forEach((btn) => {
  btn.addEventListener('click', () => document.getElementById(btn.dataset.close).classList.remove('open'));
});
document.querySelectorAll('.modal-overlay').forEach((overlay) => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

// ---- Notifications (shared with dashboard) ----
async function loadNotifications() {
  const data = await Api.get('/notifications');
  notifications = data.notifications;
  const unread = notifications.filter((n) => !n.read).length;
  const badge = document.getElementById('bell-badge');
  badge.style.display = unread ? 'flex' : 'none';
  badge.textContent = unread;

  const list = document.getElementById('notif-list');
  list.innerHTML = notifications.length
    ? notifications
        .map(
          (n) => `<div class="notif-item ${n.read ? '' : 'unread'}">${escapeHtml(n.message)}<span class="notif-time mono">${timeAgo(n.createdAt)}</span></div>`
        )
        .join('')
    : '<div class="notif-empty">Nothing here yet.</div>';
}

const bellBtn = document.getElementById('bell-btn');
const dropdown = document.getElementById('notif-dropdown');
bellBtn.addEventListener('click', () => dropdown.classList.toggle('open'));
document.addEventListener('click', (e) => {
  if (!dropdown.contains(e.target) && e.target !== bellBtn) dropdown.classList.remove('open');
});
document.getElementById('mark-all-read').addEventListener('click', async () => {
  await Api.patch('/notifications/read-all', {});
  loadNotifications();
});

document.getElementById('logout-link').addEventListener('click', (e) => {
  e.preventDefault();
  Api.clearSession();
  window.location.href = 'index.html';
});

// ---- Realtime ----
function initSocket() {
  socket = io('http://localhost:5000', { auth: { token: Api.token() } });
  socket.on('connect', () => socket.emit('project:join', projectId));

  socket.on('task:created', ({ task }) => {
    if (!tasks.some((t) => t._id === task._id)) tasks.push(task);
    renderBoard();
  });
  socket.on('task:updated', ({ task }) => {
    tasks = tasks.map((t) => (t._id === task._id ? task : t));
    renderBoard();
  });
  socket.on('task:deleted', ({ taskId }) => {
    tasks = tasks.filter((t) => t._id !== taskId);
    renderBoard();
  });
  socket.on('comment:added', ({ taskId }) => {
    if (taskId === activeTaskId) loadComments(taskId);
  });
  socket.on('notification:new', () => {
    loadNotifications();
    showToast('You have a new notification');
  });
}

(async function init() {
  renderSidebarUser();
  await loadSidebarProjects();
  await loadProject();
  await loadTasks();
  await loadNotifications();
  initSocket();
})();
