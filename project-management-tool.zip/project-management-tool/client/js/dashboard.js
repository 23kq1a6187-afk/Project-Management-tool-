Api.requireAuth();

const user = Api.user();
let notifications = [];

function renderSidebarUser() {
  document.getElementById('sidebar-user').innerHTML = `
    <span class="avatar">${initials(user.name)}</span>
    <span>${user.name}</span>
  `;
}

async function loadProjects() {
  const { projects } = await Api.get('/projects');
  renderSidebar(projects);
  renderGrid(projects);
}

function renderSidebar(projects) {
  const list = document.getElementById('sidebar-project-list');
  if (!projects.length) {
    list.innerHTML = '<li class="muted" style="padding:9px 10px;font-size:13px;">No projects yet</li>';
    return;
  }
  list.innerHTML = projects
    .map((p) => `<li><a href="board.html?id=${p._id}">${escapeHtml(p.name)}</a></li>`)
    .join('');
}

function renderGrid(projects) {
  const grid = document.getElementById('dash-grid');
  const cards = projects
    .map((p) => {
      const memberCount = p.members ? p.members.length : 1;
      return `
        <a class="project-card" href="board.html?id=${p._id}">
          <h3>${escapeHtml(p.name)}</h3>
          <p>${escapeHtml(p.description || 'No description yet.')}</p>
          <div class="meta-row">
            <span>${memberCount} member${memberCount === 1 ? '' : 's'}</span>
            <span>Owner: ${p.owner && p.owner._id === user.id ? 'You' : (p.owner ? escapeHtml(p.owner.name) : '')}</span>
          </div>
        </a>`;
    })
    .join('');

  grid.innerHTML = `
    ${cards}
    <button class="new-project-card" id="open-new-project">
      <span style="font-size:22px;">+</span>
      New project
    </button>
  `;
  document.getElementById('open-new-project').addEventListener('click', () => {
    document.getElementById('new-project-overlay').classList.add('open');
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---- New project modal ----
const overlay = document.getElementById('new-project-overlay');
document.getElementById('close-new-project').addEventListener('click', () => overlay.classList.remove('open'));
document.getElementById('cancel-new-project').addEventListener('click', () => overlay.classList.remove('open'));
overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.remove('open'); });

document.getElementById('new-project-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById('np-error');
  errorEl.textContent = '';
  try {
    const name = document.getElementById('np-name').value.trim();
    const description = document.getElementById('np-description').value.trim();
    const { project } = await Api.post('/projects', { name, description });
    overlay.classList.remove('open');
    document.getElementById('new-project-form').reset();
    showToast(`Project "${project.name}" created`);
    loadProjects();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

// ---- Notifications ----
async function loadNotifications() {
  const data = await Api.get('/notifications');
  notifications = data.notifications;
  renderNotifications();
}

function renderNotifications() {
  const unread = notifications.filter((n) => !n.read).length;
  const badge = document.getElementById('bell-badge');
  badge.style.display = unread ? 'flex' : 'none';
  badge.textContent = unread;

  const list = document.getElementById('notif-list');
  if (!notifications.length) {
    list.innerHTML = '<div class="notif-empty">Nothing here yet. Activity on your projects will show up in this list.</div>';
    return;
  }
  list.innerHTML = notifications
    .map(
      (n) => `
      <div class="notif-item ${n.read ? '' : 'unread'}">
        ${escapeHtml(n.message)}
        <span class="notif-time mono">${timeAgo(n.createdAt)}</span>
      </div>`
    )
    .join('');
}

const bellBtn = document.getElementById('bell-btn');
const dropdown = document.getElementById('notif-dropdown');
bellBtn.addEventListener('click', () => dropdown.classList.toggle('open'));
document.addEventListener('click', (e) => {
  if (!dropdown.contains(e.target) && e.target !== bellBtn) dropdown.classList.remove('open');
});
document.getElementById('mark-all-read').addEventListener('click', async () => {
  await Api.patch('/notifications/read-all', {});
  loadNotifications();
});

document.getElementById('logout-link').addEventListener('click', (e) => {
  e.preventDefault();
  Api.clearSession();
  window.location.href = 'index.html';
});

// ---- Realtime ----
function initSocket() {
  const socket = io('http://localhost:5000', { auth: { token: Api.token() } });
  socket.on('notification:new', () => {
    loadNotifications();
    showToast('You have a new notification');
  });
}

renderSidebarUser();
loadProjects();
loadNotifications();
initSocket();
