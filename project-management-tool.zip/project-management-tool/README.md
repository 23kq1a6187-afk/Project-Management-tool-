# Ledger — Project Management Tool (Task 3)

A full-stack collaborative tool similar to Trello/Asana. Users can create projects,
invite teammates, organize work on a kanban board, assign tasks, and comment on
them — with live updates pushed over WebSockets (Socket.io) as the bonus feature.

## Stack

- **Backend:** Node.js, Express, MongoDB (Mongoose), JWT auth, Socket.io
- **Frontend:** HTML, CSS, vanilla JavaScript (no build step)
- **Real-time:** Socket.io — task creation/updates/deletes, new comments, and
  notifications broadcast instantly to everyone viewing a project

## Features

- Email/password authentication (JWT, hashed passwords with bcrypt)
- Create projects and invite members by email
- Kanban board with **drag-and-drop** between To Do / In Progress / Done
- Tasks with description, priority, assignee, and due date
- Comment threads on each task
- In-app notifications (assigned to a task, added to a project, new comment)
- Everything above updates live for every connected member via WebSockets

## Folder structure

```
project-management-tool/
├── server/      Express API + Socket.io + MongoDB models
└── client/      Static HTML/CSS/JS frontend (no framework, no build tools)
```

## 1. Run the backend

```bash
cd server
npm install
cp .env.example .env
```

Edit `.env`:
- `MONGO_URI` — a local MongoDB instance (`mongodb://localhost:27017/pmtool`) or
  a free MongoDB Atlas connection string
- `JWT_SECRET` — any long random string
- `CLIENT_URL` — where the frontend will run (default below assumes `http://localhost:5500`)

Start the server:

```bash
npm run dev
```

You should see `MongoDB connected` and `Server running on http://localhost:5000`.

## 2. Run the frontend

The client is static files, so any static server works. The simplest option:

```bash
cd client
npx serve -l 5500
```

(or use the VS Code "Live Server" extension, or Python's
`python -m http.server 5500`). Then open `http://localhost:5500`.

If you run the frontend on a different port, update `CLIENT_URL` in the
server's `.env` **and** `API_BASE` at the top of `client/js/api.js` and the
socket URLs in `dashboard.js` / `board.js`.

## 3. Try it out

1. Register two accounts (e.g. in two browser windows/incognito tabs).
2. With account A, create a project and invite account B's email.
3. Open the project board on both accounts — create tasks, drag them between
   columns, assign them, comment on them, and watch updates appear instantly
   on the other account without refreshing.

## Notes on the bonus requirement

Real-time updates are implemented with Socket.io rooms: each connected user
joins a personal room (`user:<id>`) for notifications, and joins a
`project:<id>` room while viewing that project's board. Task and comment
events are emitted to the project room; assignment/invite/comment
notifications are emitted to the relevant user's personal room.
