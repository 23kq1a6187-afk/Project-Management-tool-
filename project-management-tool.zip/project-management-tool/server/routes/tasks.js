const express = require('express');
const Task = require('../models/Task');
const Project = require('../models/Project');
const Notification = require('../models/Notification');
const auth = require('../middleware/auth');

const router = express.Router();

async function requireMembership(projectId, userId) {
  const project = await Project.findById(projectId);
  if (!project) return null;
  const isMember =
    project.owner.toString() === userId || project.members.some((m) => m.user.toString() === userId);
  return isMember ? project : null;
}

// GET /api/tasks/:projectId - list tasks for a project (grouped by status on the client)
router.get('/:projectId', auth, async (req, res) => {
  try {
    const project = await requireMembership(req.params.projectId, req.userId);
    if (!project) return res.status(403).json({ message: 'You are not a member of this project' });

    const tasks = await Task.find({ project: project._id })
      .sort({ createdAt: 1 })
      .populate('assignedTo', 'name email')
      .populate('createdBy', 'name email');

    res.json({ tasks });
  } catch (err) {
    res.status(500).json({ message: 'Could not load tasks', error: err.message });
  }
});

// POST /api/tasks/:projectId - create a task in a project
router.post('/:projectId', auth, async (req, res) => {
  try {
    const project = await requireMembership(req.params.projectId, req.userId);
    if (!project) return res.status(403).json({ message: 'You are not a member of this project' });

    const { title, description, priority, assignedTo, dueDate } = req.body;
    if (!title) return res.status(400).json({ message: 'Task title is required' });

    const task = await Task.create({
      project: project._id,
      title,
      description,
      priority,
      assignedTo: assignedTo || null,
      dueDate: dueDate || null,
      createdBy: req.userId,
    });
    await task.populate('assignedTo', 'name email');
    await task.populate('createdBy', 'name email');

    const io = req.app.get('io');
    io.to(`project:${project._id}`).emit('task:created', { task });

    if (assignedTo && assignedTo !== req.userId) {
      await Notification.create({
        user: assignedTo,
        message: `You were assigned to "${task.title}" in "${project.name}"`,
        project: project._id,
        task: task._id,
      });
      io.to(`user:${assignedTo}`).emit('notification:new', {
        message: `You were assigned to "${task.title}" in "${project.name}"`,
        projectId: project._id,
      });
    }

    res.status(201).json({ task });
  } catch (err) {
    res.status(500).json({ message: 'Could not create task', error: err.message });
  }
});

// PATCH /api/tasks/item/:id - update a task (status, assignee, priority, etc.)
router.patch('/item/:id', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    const project = await requireMembership(task.project, req.userId);
    if (!project) return res.status(403).json({ message: 'You are not a member of this project' });

    const allowed = ['title', 'description', 'status', 'priority', 'assignedTo', 'dueDate'];
    const previousAssignee = task.assignedTo ? task.assignedTo.toString() : null;

    allowed.forEach((field) => {
      if (req.body[field] !== undefined) task[field] = req.body[field] || null;
    });
    await task.save();
    await task.populate('assignedTo', 'name email');
    await task.populate('createdBy', 'name email');

    const io = req.app.get('io');
    io.to(`project:${project._id}`).emit('task:updated', { task });

    const newAssignee = task.assignedTo ? task.assignedTo._id.toString() : null;
    if (newAssignee && newAssignee !== previousAssignee && newAssignee !== req.userId) {
      await Notification.create({
        user: newAssignee,
        message: `You were assigned to "${task.title}" in "${project.name}"`,
        project: project._id,
        task: task._id,
      });
      io.to(`user:${newAssignee}`).emit('notification:new', {
        message: `You were assigned to "${task.title}" in "${project.name}"`,
        projectId: project._id,
      });
    }

    res.json({ task });
  } catch (err) {
    res.status(500).json({ message: 'Could not update task', error: err.message });
  }
});

// DELETE /api/tasks/item/:id
router.delete('/item/:id', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    const project = await requireMembership(task.project, req.userId);
    if (!project) return res.status(403).json({ message: 'You are not a member of this project' });

    await task.deleteOne();

    const io = req.app.get('io');
    io.to(`project:${project._id}`).emit('task:deleted', { taskId: task._id });

    res.json({ message: 'Task deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Could not delete task', error: err.message });
  }
});

module.exports = router;
