const express = require('express');
const Comment = require('../models/Comment');
const Task = require('../models/Task');
const Project = require('../models/Project');
const Notification = require('../models/Notification');
const auth = require('../middleware/auth');

const router = express.Router();

async function requireTaskAccess(taskId, userId) {
  const task = await Task.findById(taskId);
  if (!task) return { task: null, project: null };
  const project = await Project.findById(task.project);
  const isMember =
    project && (project.owner.toString() === userId || project.members.some((m) => m.user.toString() === userId));
  return { task, project: isMember ? project : null };
}

// GET /api/comments/:taskId - list comments for a task
router.get('/:taskId', auth, async (req, res) => {
  try {
    const { task, project } = await requireTaskAccess(req.params.taskId, req.userId);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    if (!project) return res.status(403).json({ message: 'You are not a member of this project' });

    const comments = await Comment.find({ task: task._id })
      .sort({ createdAt: 1 })
      .populate('author', 'name email');
    res.json({ comments });
  } catch (err) {
    res.status(500).json({ message: 'Could not load comments', error: err.message });
  }
});

// POST /api/comments/:taskId - add a comment
router.post('/:taskId', auth, async (req, res) => {
  try {
    const { task, project } = await requireTaskAccess(req.params.taskId, req.userId);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    if (!project) return res.status(403).json({ message: 'You are not a member of this project' });

    const { text } = req.body;
    if (!text) return res.status(400).json({ message: 'Comment text is required' });

    const comment = await Comment.create({ task: task._id, author: req.userId, text });
    await comment.populate('author', 'name email');

    const io = req.app.get('io');
    io.to(`project:${project._id}`).emit('comment:added', { taskId: task._id, comment });

    if (task.assignedTo && task.assignedTo.toString() !== req.userId) {
      await Notification.create({
        user: task.assignedTo,
        message: `New comment on "${task.title}"`,
        project: project._id,
        task: task._id,
      });
      io.to(`user:${task.assignedTo}`).emit('notification:new', {
        message: `New comment on "${task.title}"`,
        projectId: project._id,
      });
    }

    res.status(201).json({ comment });
  } catch (err) {
    res.status(500).json({ message: 'Could not add comment', error: err.message });
  }
});

module.exports = router;
