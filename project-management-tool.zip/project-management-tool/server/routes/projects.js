const express = require('express');
const Project = require('../models/Project');
const User = require('../models/User');
const Task = require('../models/Task');
const Notification = require('../models/Notification');
const auth = require('../middleware/auth');

const router = express.Router();

// helper: is the user a member (or owner) of the project?
async function getMembership(projectId, userId) {
  const project = await Project.findById(projectId);
  if (!project) return { project: null, isMember: false };
  const isOwner = project.owner.toString() === userId;
  const isMember = isOwner || project.members.some((m) => m.user.toString() === userId);
  return { project, isMember, isOwner };
}

// POST /api/projects - create a project
router.post('/', auth, async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name) return res.status(400).json({ message: 'Project name is required' });

    const project = await Project.create({
      name,
      description,
      owner: req.userId,
      members: [{ user: req.userId, role: 'owner' }],
    });

    res.status(201).json({ project });
  } catch (err) {
    res.status(500).json({ message: 'Could not create project', error: err.message });
  }
});

// GET /api/projects - list projects the current user owns or belongs to
router.get('/', auth, async (req, res) => {
  try {
    const projects = await Project.find({ 'members.user': req.userId })
      .sort({ updatedAt: -1 })
      .populate('owner', 'name email');
    res.json({ projects });
  } catch (err) {
    res.status(500).json({ message: 'Could not load projects', error: err.message });
  }
});

// GET /api/projects/:id - project detail with members populated
router.get('/:id', auth, async (req, res) => {
  try {
    const { project, isMember } = await getMembership(req.params.id, req.userId);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    if (!isMember) return res.status(403).json({ message: 'You are not a member of this project' });

    await project.populate('owner', 'name email');
    await project.populate('members.user', 'name email');
    res.json({ project });
  } catch (err) {
    res.status(500).json({ message: 'Could not load project', error: err.message });
  }
});

// POST /api/projects/:id/members - invite a member by email
router.post('/:id/members', auth, async (req, res) => {
  try {
    const { email } = req.body;
    const { project, isMember } = await getMembership(req.params.id, req.userId);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    if (!isMember) return res.status(403).json({ message: 'You are not a member of this project' });

    const user = await User.findOne({ email: (email || '').toLowerCase() });
    if (!user) return res.status(404).json({ message: 'No account found with that email' });

    const already = project.members.some((m) => m.user.toString() === user._id.toString());
    if (already) return res.status(409).json({ message: 'That person is already a member' });

    project.members.push({ user: user._id, role: 'member' });
    await project.save();

    await Notification.create({
      user: user._id,
      message: `You were added to the project "${project.name}"`,
      project: project._id,
    });

    const io = req.app.get('io');
    io.to(`user:${user._id}`).emit('notification:new', {
      message: `You were added to the project "${project.name}"`,
      projectId: project._id,
    });

    await project.populate('members.user', 'name email');
    res.status(201).json({ project });
  } catch (err) {
    res.status(500).json({ message: 'Could not add member', error: err.message });
  }
});

// DELETE /api/projects/:id - owner only
router.delete('/:id', auth, async (req, res) => {
  try {
    const { project, isOwner } = await getMembership(req.params.id, req.userId);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    if (!isOwner) return res.status(403).json({ message: 'Only the owner can delete this project' });

    await Task.deleteMany({ project: project._id });
    await project.deleteOne();
    res.json({ message: 'Project deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Could not delete project', error: err.message });
  }
});

module.exports = router;
module.exports.getMembership = getMembership;
